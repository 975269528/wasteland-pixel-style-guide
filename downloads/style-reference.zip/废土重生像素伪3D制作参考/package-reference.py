"""Validate local guide references, record content hashes and build the offline sharing ZIP."""
import hashlib
import json
import re
import zipfile
from html.parser import HTMLParser
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ARCHIVE_ROOT = "废土重生像素伪3D制作参考"
ALLOWED_SUFFIXES = {".md", ".html", ".css", ".mjs", ".py", ".json", ".png", ".gif"}


class ReaderReferences(HTMLParser):
    """Collect the local reader's resource paths and section navigation targets."""

    def __init__(self) -> None:
        """Initialize independent reference and section inventories."""
        super().__init__()
        self.references: list[str] = []
        self.sections: set[str] = set()

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        """Read resource links and IDs without executing any document content."""
        values = dict(attrs)
        if values.get("id"):
            self.sections.add(values["id"])
        for name in ("src", "href"):
            if values.get(name):
                self.references.append(values[name])


def verify_reference(reference: str, sections: set[str]) -> None:
    """Require an existing package-local file or a valid local section anchor."""
    if reference.startswith("data:"):
        return
    if reference.startswith("#"):
        if reference[1:] not in sections:
            raise ValueError(f"Missing section: {reference}")
        return
    if ":" in reference or reference.startswith(("/", "\\")):
        raise ValueError(f"Nonportable resource reference: {reference}")
    target = (ROOT / reference).resolve()
    if not target.is_relative_to(ROOT) or not target.is_file():
        raise ValueError(f"Missing package resource: {reference}")


def verify_reader() -> int:
    """Check HTML and Markdown links independently of browser caches or original project files."""
    parser = ReaderReferences()
    parser.feed((ROOT / "index.html").read_text(encoding="utf-8"))
    for reference in parser.references:
        verify_reference(reference, parser.sections)
    for source in ROOT.rglob("*.md"):
        for reference in re.findall(r"!?\[[^\]]*\]\(([^)]+)\)", source.read_text(encoding="utf-8")):
            verify_reference(reference, parser.sections)
    return len(parser.references)


def package_files() -> list[Path]:
    """Select only documentation, source tools and curated media, excluding caches."""
    return sorted(path for path in ROOT.rglob("*") if path.is_file()
                  and "__pycache__" not in path.parts and path.suffix in ALLOWED_SUFFIXES
                  and path.name != "package-manifest.json")


def main() -> None:
    """Build a portable archive and verify that its entries match the source content hashes."""
    references = verify_reader()
    files = package_files()
    hashes = {path.relative_to(ROOT).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest() for path in files}
    manifest = ROOT / "package-manifest.json"
    manifest.write_text(json.dumps({"game_version": "adbd259", "sha256": hashes}, ensure_ascii=False, indent=2), encoding="utf-8")
    destination = ROOT.parents[1] / "dist" / f"{ARCHIVE_ROOT}.zip"
    destination.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(destination, "w", zipfile.ZIP_DEFLATED) as archive:
        for path in files + [manifest]:
            archive.write(path, f"{ARCHIVE_ROOT}/{path.relative_to(ROOT).as_posix()}")
    with zipfile.ZipFile(destination) as archive:
        if archive.testzip() is not None:
            raise ValueError("ZIP integrity check failed")
        for name, expected in hashes.items():
            if hashlib.sha256(archive.read(f"{ARCHIVE_ROOT}/{name}")).hexdigest() != expected:
                raise ValueError(f"Archive content mismatch: {name}")
    print(json.dumps({"files": len(files) + 1, "reader_references": references, "zip_bytes": destination.stat().st_size}))


if __name__ == "__main__":
    main()
