/** Build a self-contained offline reader from the five trusted local Markdown sources. */
import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const root = dirname(fileURLToPath(import.meta.url));
const STYLE_VERSION_LENGTH = 12;
const pages = [
  { file: 'README.md', id: 'overview', label: '开始阅读' },
  { file: 'style-guide.md', id: 'style', label: '风格规范' },
  { file: 'implementation.md', id: 'implementation', label: '实现流程' },
  { file: 'troubleshooting.md', id: 'problems', label: '问题与解决' },
  { file: 'reuse-checklist.md', id: 'reuse', label: '复用检查' },
];

/** Load the supplied marked ESM entry, or the maintainer's installed marked package. */
async function loadRenderer() {
  const modulePath = process.argv[2];
  return import(modulePath ? pathToFileURL(resolve(modulePath)).href : 'marked');
}

/** Convert document links into reader sections while retaining local media references. */
function linkDocuments(html) {
  let content = html;
  for (const page of pages) {
    content = content.replaceAll(`href="${page.file}"`, `href="#${page.id}"`);
  }
  const tableRegion = '<div class="table-scroll" role="region" aria-label="可横向滚动的表格" tabindex="0">'
    + '<p class="table-hint">表格较宽时，可左右滑动查看。</p><table>';
  return content.replaceAll('<table>', tableRegion)
    .replaceAll('</table>', '</table></div>');
}

/** Render each source in the requested reading order, with its own navigation target. */
async function renderSections(marked) {
  const sections = [];
  for (const page of pages) {
    const source = await readFile(join(root, page.file), 'utf8');
    sections.push(`<section id="${page.id}">${linkDocuments(marked.parse(source))}</section>`);
  }
  return sections.join('\n');
}

/** Write a local HTML document requiring no scripts, network or browser storage. */
async function main() {
  const { marked } = await loadRenderer();
  const body = await renderSections(marked);
  const navigation = pages.map(page => `<a href="#${page.id}">${page.label}</a>`).join('\n');
  const cssContent = await readFile(join(root, 'reader.css'));
  const cssVersion = createHash('sha256').update(cssContent).digest('hex').slice(0, STYLE_VERSION_LENGTH);
  const html = `<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>废土重生 像素伪3D制作参考</title><link rel="icon" href="data:,"><link rel="stylesheet" href="reader.css?v=${cssVersion}"></head>
<body><aside><p class="brand">废土重生</p><p class="subtitle">像素伪3D制作参考</p>
<nav class="desktop-nav" aria-label="文档目录">${navigation}</nav>
<details class="mobile-menu"><summary>文档目录</summary><nav aria-label="手机文档目录">${navigation}</nav></details>
<p class="note">2026 年 10 月 9 日<br>离线文档 · 实际效果预览</p></aside>
<main>${body}<footer>完整分享请保留此目录中的 media 文件夹。</footer></main></body></html>`;
  await writeFile(join(root, 'index.html'), html, 'utf8');
  process.stdout.write(`Built ${pages.length} offline document sections.\n`);
}

await main();
